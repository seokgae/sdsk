package sqltest_board;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class ProcBoard {
	Connection con = null;
	Statement st = null;
	ResultSet result = null;
	
	static int current_page = 1;
	private static int total_post;
	private String reply_indent = "";
	ArrayList<Statement> reply_sts = new ArrayList<>();
	ArrayList<ResultSet> reply_res = new ArrayList<>();

	void run() {
		dbInit();
		String query = "SELECT * FROM board_basic WHERE b_title IS NOT NULL";//댓글을 제외한 게시글 쿼리
		total_post = dbMaxPage(query);//전체 게시글 개수 참조
		max_page();//게시판 페이지 수 계산
	}
	
	void max_page() {
		//전체 게시글 수
		if(total_post % Board.postperpage ==0) {Board.Max_Page = total_post/Board.postperpage;}
		else {Board.Max_Page = total_post/Board.postperpage+1;}
	}
	
	void B_main() {
		Display.drawHead();//대가리
		Display.drawMenu();//명령메뉴
		System.out.print("명령 : ");
		String exec = Board.sc.next();
		if(exec.equals("1")) {Board.sel.WR();}
		else if(exec.equals("2")) {current_page=1;Board.sel.LI();}
		else if(exec.equals("3")) {Board.sel.SE();}
		else if(exec.equals("x")) {Board.sel.main = false; Board.sel.exit = true;}
	}
	
	
	void B_write() {
		System.out.println("=======================================");
		System.out.print("글 제목: ");
		String title = Board.sc.nextLine();
		System.out.print("작성자: ");
		String writerID = Board.sc.next();
		System.out.print("글 내용: ");
		String context = Board.sc.nextLine();
		System.out.println("=======================================");
		
		String input = String.format("INSERT INTO board_basic (b_title,b_writerID,b_datetime,b_cont) VALUES ('%s','%s',now(),'%s');", title, writerID, context);
		dbExecuteUpdate(input);
		total_post++;
		max_page();
		
		Board.sel.main();
	}
	
	boolean B_readIn(String b_no) { //글 조회 화면 TODO 회원정보 연동
		Display.drawB_ReadIN();		
		String which = Board.sc.next(); 
		
		if(which.equals("1")) {B_update(b_no); return false;} // 1.글 수정
		else if(which.equals("2")) {B_remove(b_no); return false;}// 2. 글 삭제
		else if(which.equals("3")) {while(B_reply(b_no)); return false;}// 3. 댓글 작성
		else if(which.equals("x")) {Board.sel.LI(); return false;}// x. 목록으로
		
		return true;
	}
	
	boolean B_reply(String b_no) { //input b_no = 조회한 원 글 번호
		System.out.print("[1.원글에 작성][2.대댓글 작성]");
		String which = Board.sc.next();
		
		if(which.equals("1")) {
			System.out.print("작성자 :");
			String writerID = Board.sc.next();
			System.out.print("\n내용 :");
			String context = Board.sc.nextLine();
			String query = String.format("INSERT INTO board_basic (b_writerID, b_datetime, b_cont, tag_b_no) VALUES ('%s', now(), '%s', '%s');",
					writerID, context, b_no);
			dbExecuteUpdate(query);
			return false;
		}
		else if(which.equals("2")) {
			System.out.print("태그할 댓글 번호 :");
			String tag_b_no = Board.sc.next();
			System.out.print("\n작성자 :");
			String writerID = Board.sc.next();
			System.out.print("\n내용 :");
			String context = Board.sc.nextLine();
			String query = String.format("INSERT INTO board_basic (b_writerID, b_datetime, b_cont, tag_b_no) VALUES ('%s', now(), '%s', '%s');",
					writerID, context, tag_b_no);
			dbExecuteUpdate(query);
			return false;
		}
		
		return true;
	}
	
	void B_list() {//글 리스트
		Display.drawList();
		String query = String.format("SELECT * FROM board_basic WHERE b_title IS NOT NULL LIMIT %s, %s", (current_page - 1) * 5, Integer.toString(Board.postperpage));//
		dbPageList(query, Board.Max_Page);// 리스트 출력
		System.out.println("=======================================================================");
		while(true) {
			System.out.print("----->조회할 글 번호(a:이전페이지 d:다음페이지 x:뒤로) : ");
			String search = Board.sc.next();//조회할 글 번호 입력
			String se_query = String.format("SELECT * FROM board_basic WHERE b_no ='%s';",search);
			if(dbRD(se_query)) { while(B_readIn(search)); break;} //글 읽어오기 글 번호 입력 예외 시 continue
			else if(search.equals("a")) {if(current_page>1)current_page--; break;} //a. 이전페이지
			else if(search.equals("d")) {current_page++; if(current_page>Board.Max_Page) {current_page=1;} break;} //b. 다음페이지 - 마지막페이지 도달 시 1페이지로
			else if(search.equals("x")) {Board.sel.main();break;} // x:메인으로
		}
	}
	
	void B_update(String b_no) { // 글 수정
		System.out.print("수정 글 내용: ");
		String toCont = Board.sc.nextLine();
		String query = String.format("UPDATE board_basic SET b_cont = '%s' WHERE b_no = '%s';", toCont, b_no);
		dbExecuteUpdate(query);
	}
	
	void B_remove(String b_no) {// 글 삭제
		String query = String.format("DELETE FROM board_basic WHERE b_no = '%s';", b_no);
		dbRemove(query); 
		if (total_post % Board.postperpage == 1) {current_page--;}//페이지의 유일한 글 삭제 시 현재 페이지 갱신
		total_post--;
		max_page();
	}
	

	private void dbInit() { //db로드
		try {
			// (1/n) 디비 접속 정보 넣어서 접속하기
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/my_cat", "root", "root");
			// (2/n) Statement 객체 얻어오기.
			st = con.createStatement(); // Statement는 정적 SQL문을 실행하고 결과를 반환받기 위한 객체다. Statement하나당 한개의 ResultSet 객체만을 열
										// 수있다.
		} catch (SQLException e) {
			System.out.println("SQLException: " + e.getMessage());
			System.out.println("SQLState: " + e.getSQLState());
		}
	}

	private boolean dbRD(String query) {//글 조회
		int t = 0;
		String b_no = null;
		try {
			result = st.executeQuery(query);
			while (result.next()) { // 결과를 하나씩 빼기. 더 이상 없으면(행 수가 끝나면) false 리턴됨.
				b_no = result.getString("b_no");
				System.out.println("*   *   *   *   *   *   *   *   *   *   *   *   *   *   *   *   *");
				System.out.print("제목:"+result.getString("b_title"));
				System.out.print(" | 작성자:"+result.getString("b_writerID"));
				System.out.print(" | 작성시간:"+result.getString("b_datetime")+"\n");
				System.out.println("글 내용:"+result.getString("b_cont"));
				t++;
			}
		} catch (SQLException e) {
			System.out.println("SQLException: " + e.getMessage());
			System.out.println("SQLState: " + e.getSQLState());
		}
		if(t==0) {return false;}//글 번호 validity체크
		
		
		int i = 0; //reply재귀용 인덱스
		if(b_no != null) {dbReply(b_no, i);}
		System.out.println("*   *   *   *   *   *   *   *   *   *   *   *   *   *   *   *   *");
		
		return true;
	}
	
	private int dbMaxPage(String query) {//게시글 수 조회 
		int t = 0;
		try {
			result = st.executeQuery(query);
			while (result.next()) { 
				t++;
			}
		} catch (SQLException e) {
			System.out.println("SQLException: " + e.getMessage());
			System.out.println("SQLState: " + e.getSQLState());
		}
		
		return t;//전체 게시글 수
	}
	
	private void dbRemove(String query) { // 글삭제 db
		try {
			int resultCount = st.executeUpdate(query);
			System.out.println("처리된 행 수:" + resultCount);
		} catch (SQLException e) {
			System.out.println("SQLException: " + e.getMessage());
			System.out.println("SQLState: " + e.getSQLState());
		}
	}
	
	
	private void dbPageList(String query, int Max_Page) {// 글리스트 (페이징)db
		try {
			result = st.executeQuery(query);
			while (result.next()) { // 결과를 하나씩 빼기. 더 이상 없으면(행 수가 끝나면) false 리턴됨.
				System.out.println(String.format("[%s] 제목: %-20s | 작성자: %s | 작성시간: %s", 
						result.getString("b_no"), result.getString("b_title"), result.getString("b_writerID"), result.getString("b_datetime")));
			}
			for(int i = 1; i< Max_Page+1; i++ ) {
				if(i == current_page) {System.out.print(String.format("<%s>", Integer.toString(i)));}
				else {System.out.print(String.format("[%s]", Integer.toString(i)));}
			}
			System.out.println("");
		} catch (SQLException e) {
			System.out.println("SQLException: " + e.getMessage());
			System.out.println("SQLState: " + e.getSQLState());
		}
	}
	
	private void dbExecuteUpdate(String query) {// 글 수정db
		try {
			// (3/n) Statement 객체의 executeUpdate함수에 sql문 실어서 디비에서 실행되게 하기
			int resultCount = st.executeUpdate(query); // 이거 하는 순간 디비에 sql(쿼리) 날아감. (디비에 반영됨)
			System.out.println("처리된 행 수:" + resultCount);
		} catch (SQLException e) {
			System.out.println("SQLException: " + e.getMessage());
			System.out.println("SQLState: " + e.getSQLState());
		}
	}
	
	private void dbReply(String b_no, int i) { //댓글 출력
		int temp = i;
		try {
			String query = String.format("SELECT * FROM board_basic WHERE b_title IS NULL AND tag_b_no = '%s'", b_no); //tag_b_no = b_no b_no에 태그된 글 긁어오기
			reply_sts.add(con.createStatement()); // statement, resultset생성
			reply_res.add(reply_sts.get(i).executeQuery(query));
			Statement rep_st = reply_sts.get(i);
			ResultSet rep_res = reply_res.get(i);
			i++;
			reply_indent += "  ";//댓글 들여쓰기 처리
					while (rep_res.next()) {
						System.out.println(String.format("%sㄴ[%s] %s | 작성자:%s | 작성시간:%s ",
								reply_indent, rep_res.getString("b_no"), rep_res.getString("b_cont"), rep_res.getString("b_writerID"), rep_res.getString("b_datetime")));
						b_no = rep_res.getString("b_no");
						
						dbReply(b_no, i);
					}
			rep_st.close(); // statement, resultset해제 및 arraylist에서 제거
			rep_res.close();
			reply_sts.remove(temp);
			reply_res.remove(temp);
			reply_indent = reply_indent.substring(0, reply_indent.length()-2); //들여쓰기 단계 별 제거
		} catch (SQLException e) {
			System.out.println("SQLException: " + e.getMessage());
			System.out.println("SQLState: " + e.getSQLState());
		}
	}
	
//	private void dbList(String query) {
//		try {
//			result = st.executeQuery(query);
//			while (result.next()) { 
//				System.out.println(String.format("[%s] 제목: %-20s | 작성자: %s | 작성시간: %s", 
//						result.getString("b_no"), result.getString("b_title"), result.getString("b_writerID"), result.getString("b_datetime")));
//			}
//		} catch (SQLException e) {
//			System.out.println("SQLException: " + e.getMessage());
//			System.out.println("SQLState: " + e.getSQLState());
//		}
//	}
	
	void B_search() { //제목 검색, 작성자 검색
		Display.drawB_Read();		
		String which = Board.sc.next(); 
		if(which.equals("1")) {
			System.out.print("\n검색어: ");
			String search2 = Board.sc.next();
			int searchpage;
			int temp =  dbMaxPage(String.format("SELECT * FROM board_basic WHERE b_title='%s'",search2))/5;
			if(temp%5 == 0) searchpage = temp;
			else {searchpage = temp+1;}
			System.out.println(searchpage);
			outer:
			while(true) {
				String query = String.format("SELECT * FROM board_basic WHERE b_title='%s' LIMIT %s, %s;",search2, (current_page - 1)*5, Integer.toString(Board.postperpage));
				dbPageList(query, searchpage);
				
				while(true) {
					System.out.print("----->조회할 글 번호(a:이전페이지 d:다음페이지 x:뒤로) : ");
					String search = Board.sc.next();//조회할 글 번호 입력
					String se_query = String.format("SELECT * FROM board_basic WHERE b_no ='%s';",search);
					if(dbRD(se_query)) { while(B_readIn(search)); break;} //글 읽어오기 글 번호 입력 예외 시 continue
					else if(search.equals("a")) {if(current_page>1)current_page--; break;} //a. 이전페이지
					else if(search.equals("d")) {current_page++; if(current_page>searchpage) {current_page=1;} break;} //b. 다음페이지 - 마지막페이지 도달 시 1페이지로
					else if(search.equals("x")) {Board.sel.main();break outer;} // x:메인으로
				}
			}
		}
		else if(which.equals("x")) {Board.sel.main();}
	}
}
