package sqltest_board;

import java.util.Scanner;

public class Board {
	static ScreenSelection sel;
	protected static Scanner sc = new Scanner(System.in);
	protected static int Max_Page;
	public final static int postperpage = 5;
	private ProcBoard br;
	
	Board() {
		sel = new ScreenSelection();
		br = new ProcBoard();
		br.run();
		while(logic() == true) {}
	}
	
	private boolean logic() {
		if(sel.main) {br.B_main();}
		else if(sel.WR) {br.B_write();}
		else if(sel.LI) {br.B_list();}
		else if(sel.SE) {br.B_search();}
		else if(sel.exit) {return false;}
		
		return true;
	}
	
	class ScreenSelection {
		boolean main = true;
		boolean WR = false;
		boolean SE = false;
		boolean LI = false;
		boolean UP = false;
		boolean exit = false;
		
		void main() {main = true;WR=false;SE=false;LI=false;UP=false;}
		void WR() {main = false;WR=true;SE=false;LI=false;UP=false;}
		void SE() {main = false;WR=false;SE=true;LI=false;UP=false;}
		void LI() {main = false;WR=false;SE=false;LI=true;UP=false;}
		void UP() {main = false;WR=false;SE=false;LI=false;UP=true;}
	}
}
