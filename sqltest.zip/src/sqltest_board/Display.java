package sqltest_board;

public class Display {
	static void drawHead() {
		System.out.println("=======================================");
		System.out.println("* * * * * * * * * * * * * * * * * * * *");
		System.out.println("* * * * * * * * * * * * * * * * * * * *");
		System.out.println("* * * * * * *  BoardTest  * * * * * * *");
		System.out.println("* * * * * * * * * * * * * * * * * * * *");
		System.out.println("* * * * * * * * * * * * * * * * * * * *");
	}
	
	static void drawMenu() {
		System.out.println("=======================================");
		System.out.println("      1.글 작성 2.글 리스트 x.종료     ");
		System.out.println("=======================================");
	}
	
	static void drawB_Read() {
		System.out.println("=======================================");
		System.out.println("  1.작성자 검색 2.글 제목 검색 x.뒤로  ");
		System.out.println("=======================================");
	}
	
	static void drawB_ReadIN() {
		System.out.print("----->[1.글 수정][2.글 삭제][x.목록으로] | 명령:");
	}
}
