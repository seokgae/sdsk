package sqltest_board;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Scanner;

public class ProcBoard {
	Connection con = null;
	Statement st = null;
	ResultSet result = null;
	String id_cache = "";
	ArrayList<String> last_id;
	static int current_page = 1;
	private boolean list_flag = true;

	
	ProcBoard() {
		last_id = new ArrayList<String>();
	}
	
	void run() {
		dbInit();
		max_page();
	}
	
	void max_page() {
		String query = "select * from board_basic";
		int t = dbMaxPage(query);
		if(t % 5 ==0) {	Board.Max_Page = t/5;}
		else {Board.Max_Page = t/5+1;}
	}
	
	void B_write() {
		System.out.println("=======================================");
		System.out.print("글 제목: ");
		String title = Board.sc.next();
		System.out.print("작성자: ");
		String writerID = Board.sc.next();
		System.out.print("글 내용: ");
		String context = Board.sc.next();
		System.out.println("=======================================");
		
		String input = String.format("insert into board_basic (b_title,b_writerID,b_datetime,b_cont) values ('%s','%s',now(),'%s');", title, writerID, context);
		dbExecuteUpdate(input);
		max_page();
		
		Board.sel.main();
	}
	
	void B_readIn(String b_no) { //제목 검색, 작성자 검색
		Display.drawB_ReadIN();		
		String which = Board.sc.next(); 
		
		if(which.equals("1")) {B_update(b_no); list_flag=true;}
		else if(which.equals("2")) {B_remove(b_no); max_page(); list_flag=true;}
		else if(which.equals("x")) {Board.sel.LI(); list_flag = true;}
	}
	
	void B_list() {
		
		if(list_flag) {
			System.out.println("===============================[글 목록]===============================");
//			String query = "select * from board_basic";
			String query;
//			if(current_page == 1) {
//				query = "select * from board_basic ORDER BY b_no LIMIT 0, 5";
//			}
//			else {
//				query = String.format("select * from board_basic where b_no > %s ORDER BY b_no LIMIT 0, 5",last_id.get(current_page-1));
				query = String.format("select * from board_basic LIMIT %s, 5",(current_page-1)*5);
//			}
			dbPageList(query);//리스트 출력
		}
		
		System.out.print("----->조회할 글 번호(a:이전페이지 d:다음페이지 x:뒤로) : ");
		String search = Board.sc.next();//조회할 글 번호 입력
		list_flag = false;
		String se_query = String.format("select * from board_basic where b_no='%s';",search);
		if(dbRD(se_query)) { B_readIn(search); } //글 읽어오기 글 번호 입력 예외 시 continue
		else if(search.equals("a")) {if(current_page>1)current_page--;list_flag=true;} 
		else if(search.equals("d")) {current_page++; if(current_page>Board.Max_Page) {current_page=1;} list_flag=true;} 
		else if(search.equals("x")) {Board.sel.main();list_flag=true;} // x:메인으로
	}
	
	void B_update(String b_no) {
		System.out.print("수정 글 내용: ");
		String toCont = Board.sc.next();
		String query = String.format("update board_basic set b_cont = '%s' where b_no= '%s';", toCont, b_no);
		dbExecuteUpdate(query);
	}
	
	void B_remove(String b_no) {
		String query = String.format("delete from board_basic where b_no= '%s';", b_no);
		dbRemove(query);
		if (Board.Max_Page%5 ==1) {current_page--;}
	}
	

	private void dbInit() {
		try {
			// (1/n) 디비 접속 정보 넣어서 접속하기
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/my_cat", "root", "root");
			// (2/n) Statement 객체 얻어오기.
			st = con.createStatement(); // Statement는 정적 SQL문을 실행하고 결과를 반환받기 위한 객체다. Statement하나당 한개의 ResultSet 객체만을 열
										// 수있다.
		} catch (SQLException e) {
			System.out.println("SQLException: " + e.getMessage());
			System.out.println("SQLState: " + e.getSQLState());
		}
	}

	private boolean dbRD(String query) {
		int t = 0;
		try {
			result = st.executeQuery(query);
			while (result.next()) { // 결과를 하나씩 빼기. 더 이상 없으면(행 수가 끝나면) false 리턴됨.
				System.out.println("*   *   *   *   *   *   *   *   *   *   *   *   *   *   *   *   *");
				System.out.print("제목:"+result.getString("b_title"));
				System.out.print(" | 작성자:"+result.getString("b_writerID"));
				System.out.print(" | 작성시간:"+result.getString("b_datetime")+"\n");
				System.out.println("글 내용:"+result.getString("b_cont"));
				t++;
			}
		} catch (SQLException e) {
			System.out.println("SQLException: " + e.getMessage());
			System.out.println("SQLState: " + e.getSQLState());
		}
		if(t==0) {return false;}//글 번호 validity체크
		return true;
	}
	
	private int dbMaxPage(String query) {
		int t = 0;
		try {
			result = st.executeQuery(query);
			while (result.next()) { // 결과를 하나씩 빼기. 더 이상 없으면(행 수가 끝나면) false 리턴됨.
				System.out.println("*   *   *   *   *   *   *   *   *   *   *   *   *   *   *   *   *");
				System.out.print("제목:"+result.getString("b_title"));
				System.out.print(" | 작성자:"+result.getString("b_writerID"));
				System.out.print(" | 작성시간:"+result.getString("b_datetime")+"\n");
				System.out.println("글 내용:"+result.getString("b_cont"));
				t++;
			}
		} catch (SQLException e) {
			System.out.println("SQLException: " + e.getMessage());
			System.out.println("SQLState: " + e.getSQLState());
		}
		
		return t;
	}
	
	private void dbRemove(String query) {
		try {
			int resultCount = st.executeUpdate(query);
			System.out.println("처리된 행 수:" + resultCount);
		} catch (SQLException e) {
			System.out.println("SQLException: " + e.getMessage());
			System.out.println("SQLState: " + e.getSQLState());
		}
	}
	
	private void dbList(String query) {
		try {
			result = st.executeQuery(query);
			while (result.next()) { // 결과를 하나씩 빼기. 더 이상 없으면(행 수가 끝나면) false 리턴됨.
				System.out.println(String.format("[%s] 제목: %-20s | 작성자: %s | 작성시간: %s", 
						result.getString("b_no"), result.getString("b_title"), result.getString("b_writerID"), result.getString("b_datetime")));
			}
		} catch (SQLException e) {
			System.out.println("SQLException: " + e.getMessage());
			System.out.println("SQLState: " + e.getSQLState());
		}
	}
	
	private void dbPageList(String query) {
		int t =0;
		try {
			result = st.executeQuery(query);
			while (result.next()) { // 결과를 하나씩 빼기. 더 이상 없으면(행 수가 끝나면) false 리턴됨.
				System.out.println(String.format("[%s] 제목: %-20s | 작성자: %s | 작성시간: %s", 
						result.getString("b_no"), result.getString("b_title"), result.getString("b_writerID"), result.getString("b_datetime")));
				id_cache = result.getString("b_no");
				t++;
			}
			for(int i = 1; i< Board.Max_Page+1; i++ ) {
				if(i == current_page) {System.out.print(String.format("<%s>", Integer.toString(i)));}
				else {System.out.print(String.format("[%s]", Integer.toString(i)));}
			}
//			if(last_id.isEmpty()) {last_id.add(id_cache);}
//			else if( t > 0){
//				if(last_id.get(current_page-1) == null) {last_id.add(id_cache);}
//			}
//			for(int i=0;i<last_id.size();i++) {
//				System.out.print(last_id.get(i));
//			}
			System.out.println("");
		} catch (SQLException e) {
			System.out.println("SQLException: " + e.getMessage());
			System.out.println("SQLState: " + e.getSQLState());
		}
	}
	
	private void dbExecuteUpdate(String query) {
		try {
			// (3/n) Statement 객체의 executeUpdate함수에 sql문 실어서 디비에서 실행되게 하기
			int resultCount = st.executeUpdate(query); // 이거 하는 순간 디비에 sql(쿼리) 날아감. (디비에 반영됨)
			System.out.println("처리된 행 수:" + resultCount);
		} catch (SQLException e) {
			System.out.println("SQLException: " + e.getMessage());
			System.out.println("SQLState: " + e.getSQLState());
		}
	}
	
	
//	void B_read() { //제목 검색, 작성자 검색
//		Display.drawB_Read();		
//		String which = Board.sc.next(); 
//		if(which.equals("1")) {
//			System.out.print("\n검색어: ");
//			String search = Board.sc.next();
//			String query = String.format("select * from board_basic where b_writerID='%s';",search);
//			dbRD(query);
//		}
//		else if(which.equals("2")) {
//			System.out.print("\n검색어: ");
//			String search = Board.sc.next();
//			String query = String.format("select * from board_basic where b_title='%s';",search);
//			dbRD(query);
//		}
//		else if(which.equals("x")) {Board.sel.main();}
//	}
}
