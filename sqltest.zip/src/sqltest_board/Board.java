package sqltest_board;

import java.util.Scanner;

public class Board {
	static Scanner sc = new Scanner(System.in);; 
	ProcBoard br;
	static ScreenSelection sel;
	static int Max_Page;
	
	Board() {
		sel = new ScreenSelection();
		br = new ProcBoard();
		br.run();
		while(logic() == true) {}
	}
	
	void B_main() {
		Display.drawHead();
		Display.drawMenu();
		ProcBoard.current_page = 1;
		System.out.print("명령 : ");
		String exec = sc.next();
		if(exec.equals("1")) {sel.WR();}
		else if(exec.equals("2")) {sel.LI();}
		else if(exec.equals("x")) {sel.main = false; sel.exit = true;}
	}
	

	private boolean logic() {
		if(sel.main) { B_main(); }
		else if(sel.WR) { br.B_write(); }
		else if(sel.LI) { br.B_list(); }
		else if(sel.exit) { return false; }
		
		return true;
	}
	
	class ScreenSelection {
		boolean main = true;
		boolean WR = false;
		boolean RD = false;
		boolean LI = false;
		boolean UP = false;
		boolean exit = false;
		
		void main() {main = true;WR=false;RD=false;LI=false;UP=false;}
		void WR() {main = false;WR=true;RD=false;LI=false;UP=false;}
		void RD() {main = false;WR=false;RD=true;LI=false;UP=false;}
		void LI() {main = false;WR=false;RD=false;LI=true;UP=false;}
		void UP() {main = false;WR=false;RD=false;LI=false;UP=true;}
	}
}
