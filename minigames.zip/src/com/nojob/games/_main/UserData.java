package com.nojob.games._main;

public class UserData {
	public static int wins = 0;
	public static int losses = 0;
	public static int mines_wins = 0;
	public static int mines_losses = 0;
	
	
}
