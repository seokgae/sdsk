package com.nojob.games.fall;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.ArrayList;

import javax.swing.JLabel;
import javax.swing.JPanel;

import java.awt.*;

public class ButtonEventFalls {
	/////////////////////////////////////////////////////
/////////////////////////////////////////////////////////
	public class KEY_IN implements KeyListener {
		ArrayList<JPanel> lanes;

		public KEY_IN(ArrayList<JPanel> lanes) {
			this.lanes = lanes;
		}

		@Override
		public void keyPressed(KeyEvent e) {
			if (e.getKeyChar() == 'a') {press(0);}
			if (e.getKeyChar() == 's') {press(1);}
			if (e.getKeyChar() == 'd') {press(2);}
			if (e.getKeyChar() == 'f') {press(3);}
		}

		@Override
		public void keyTyped(KeyEvent e) {
		}

		@Override
		public void keyReleased(KeyEvent e) {
			if (e.getKeyChar() == 'a') {release(0);}
			if (e.getKeyChar() == 's') {release(1);}
			if (e.getKeyChar() == 'd') {release(2);}
			if (e.getKeyChar() == 'f') {release(3);}
		}

		public void press(int i) {
			lanes.get(i).setBackground(new Color(100, 100, 100));
			for (Component note : lanes.get(i).getComponents()) {
				if (note instanceof JLabel && note.getY() > 420) {
					lanes.get(i).remove(note);
				}
			}
		}
		public void release(int i) {
			lanes.get(i).setBackground(new Color(160, 160, 160));
		}
	}

}
