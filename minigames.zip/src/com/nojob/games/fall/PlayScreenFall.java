package com.nojob.games.fall;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.*;
import java.util.ArrayList;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

import com.nojob.games._main.MainFrame;
import com.nojob.games._main.UserData;

public class PlayScreenFall extends JPanel {
	private JPanel header;
	public static JPanel middle;
	private JPanel footer;
	static ArrayList<JPanel> lanes = new ArrayList<>(); 
	static ArrayList<JLabel> notes = new ArrayList<>(); 
	static ButtonEventFalls events_falls;

public PlayScreenFall() { //// 인게임 화면
	events_falls = new ButtonEventFalls();
	setLayout(null);
	setSize(500, 900);
	
	header = new JPanel();
	middle = new JPanel();
	footer = new JPanel();
	header.setLayout(new FlowLayout(FlowLayout.CENTER, 50, 50));
	middle.setLayout(new GridLayout(1,4));///////난이도 별 레이아웃조정
	footer.setLayout(new FlowLayout(FlowLayout.CENTER, 10, 10));

	middle.setPreferredSize(new Dimension(500, 500));
	header.setBounds(0, 0, 500, 150);
	middle.setBounds(0, 150, 485, 500);
	footer.setBounds(0, 700, 500, 200);
	add(header);
	add(middle);
	add(footer);

//	Timer timer = setHeader();
	setHeader();
	setMiddle();
	setFooter();
	new FallsLogic();
}
	

public /*Timer*/ void setHeader() {
	JLabel start = new JLabel("");
	JButton reset = new JButton("초기화");
	JLabel WL = new JLabel(String.format("승 : %d / 패 : %d", UserData.wins, UserData.losses));

//	Timer timer = Util.newTimer(start);
	
//	timer.start();
//	reset.addActionListener(events_mines.new resetOnClick(header, timer, middle));
	header.add(start);
	header.add(reset);
	header.add(WL);
	
//	return timer;
}

public void setMiddle() {
	lanes.add(new JPanel());
	lanes.add(new JPanel());
	lanes.add(new JPanel());
	lanes.add(new JPanel());
	
	for(JPanel lane:lanes) {
		lane.setBorder(BorderFactory.createLineBorder(Color.black, 1));
		lane.setBackground(new Color(160,160,160));
		lane.setLayout(null);
		JPanel indicator = new JPanel();
		indicator.setBackground(new Color(0,0,0,85));
		indicator.setBounds(0,420,121,80);
		lane.add(indicator);
		middle.add(lane);
	}
	middle.addKeyListener(events_falls.new KEY_IN(lanes));
}

public void setFooter() {
	JButton toMain = new JButton("처음으로");
	toMain.addActionListener(MainFrame.events::toMain);
	
	footer.add(toMain);
}

}
