package com.nojob.games.fall;

import java.awt.*;
import java.util.ArrayList;
import javax.swing.*;

public class FallsLogic {
	ArrayList<JLabel> notes;
	ArrayList<JPanel> lanes;
	JPanel middle;
	static Thread gennote;
	static Thread movenote;

	public FallsLogic() {
		this.lanes = PlayScreenFall.lanes;
		this.notes = PlayScreenFall.notes;
		this.middle = PlayScreenFall.middle;
		
		Runnable gen = new NoteGen();
		Runnable move = new NoteMove();
		
		gennote = new Thread(gen);
		movenote = new Thread(move);
		
		gennote.start();
		movenote.start();
	}

	protected class NoteGen implements Runnable {
		
		@Override
		public void run() {
			while (true) {
				JLabel temp = new JLabel("");
				temp.setBounds(0, 0, 121, 20);
				temp.setOpaque(true);
				temp.setBorder(BorderFactory.createLineBorder(Color.black, 1));
				temp.setBackground(Color.pink);
				notes.add(temp);
				int target_lane = (int) (Math.random() * 4);
				PlayScreenFall.lanes.get(target_lane).add(temp);
				try {
					gennote.sleep((long)(Math.random()*60+300));
					movenote.sleep(1);
				} catch (Exception e) {	}
				middle.validate();
				middle.repaint();

			}
		}
	}

	protected class NoteMove implements Runnable {

		@Override
		public void run() {
			while (true) {
				delay(10);
			}
		}

		private void delay(int time) {
			try {Thread.sleep(time);} catch (Exception e) {}
			for (JLabel note : notes) { // 이동
				note.setLocation(note.getX(), note.getY() + 2);
			}
			notes.removeIf(note -> note.getY() > 500);
			for (int i = 0; i < 4; i++) {
				for (Component note : lanes.get(i).getComponents()) {
					if (note instanceof JLabel && note.getY() > 500) {
						lanes.get(i).remove(note);
					}
				}
			}
			middle.validate();
			middle.repaint();
		}
	}

}
