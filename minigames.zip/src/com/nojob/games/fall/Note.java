package com.nojob.games.fall;

import javax.swing.JLabel;

public class Note extends JLabel{
	
	public Note() {
	}
	
	
}
