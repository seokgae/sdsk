package sqltest_board;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class ProcBoard {
	Connection con = null;
	Statement st = null;
	ResultSet result = null;
	
	private int Max_Page;
	private final static int postperpage = 5;
	private String CurrentID = null;
	private String Currentpost_writerID = null;
	static boolean isSigned = false;
	static int current_page = 1;
	private static int total_post;
	private String reply_indent = "";
	ArrayList<Statement> reply_sts = new ArrayList<>();
	ArrayList<ResultSet> reply_res = new ArrayList<>();
	private final String main = "main";
	private final String MS = "MS";
	private final String WR = "WR";
	private final String SE = "SE";
	private final String LI = "LI";
	private final String SI = "SI";
	private final String UP = "UP";
	private final String LO = "LO";
	private final String exit = "exit";

	void run() {
		dbInit();
		String query = "SELECT COUNT(*) FROM board_basic WHERE b_title IS NOT NULL";//댓글을 제외한 게시글 쿼리
		total_post = dbMaxPage(query);//전체 게시글 개수 참조
		max_page();//게시판 페이지 수 계산 TODO 검색도 호환되게 maxpage개선
	}
	
	void max_page() {
		//전체 게시글 수
		if(total_post % postperpage ==0) {Max_Page = total_post/postperpage;}
		else {Max_Page = total_post/postperpage+1;}
	}
	
	void B_main() {
		Display.drawHead();//대가리
		Display.drawMenu();//명령메뉴
		System.out.print("명령 : ");
		String exec = Board.sc.nextLine();
		if(exec.equals("1")) {Sel.set(LO);}
		else if(exec.equals("2")) {current_page=1;Sel.set(LI);}
		else if(exec.equals("3")) {current_page=1;Sel.set(SI);}
		else if(exec.equals("x")) {Sel.set(exit);}
	}
	
	void B_main_signed() { //TODO 글작성 게시판에 통합
		Display.drawHead();//대가리
		Display.drawMenuSigned();//로그인 후 명령메뉴
		System.out.print("명령 : ");
		String exec = Board.sc.nextLine();
		if(exec.equals("1")) {isSigned=false;CurrentID = null;Sel.set(main);}
		else if(exec.equals("2")) {current_page=1;Sel.set(LI);}
		else if(exec.equals("3")) {current_page=1;Sel.set(SE);}
		else if(exec.equals("x")) {Sel.set(exit);}
	}
	
	void B_login() {
		System.out.print("ID : ");
		String ID = Board.sc.nextLine();
		System.out.print("PW : ");
		String PW = Board.sc.nextLine();
		
		String query = String.format("SELECT mem_PW FROM member WHERE mem_ID = '%s'",ID);
		String HI = dbLogin(query); // db상 ID와 일치하는 PW리턴
		if(HI.equals("ID_no_match")) {
			System.out.println("ID 불일치!");
			Sel.set(main);
		}
		else {
			if (HI.equals(PW)) {
				CurrentID = ID;
				isSigned = true;
				System.out.println("로그인 성공!");
				System.out.println(String.format("%s님 환영합니다!", ID));
				Sel.set(main);
			}
			else {
				System.out.println("PW 불일치!");
				Sel.set(main);
			}
		}
	} 
	
	void B_signin() {
		String ID;
		while(true) {
			System.out.print("ID : ");
			ID = Board.sc.nextLine();
			String query = String.format("SELECT COUNT(mem_ID) AS CHK FROM member WHERE mem_ID = '%s'", ID);
			String chk = dbChkID(query);
			if(chk.equals("0")) {break;}
			System.out.println("ID 중복!");
		}
		System.out.print("PW : ");
		String PW = Board.sc.nextLine();
		
		String query2 = String.format("INSERT INTO member VALUES('%s', '%s')", ID, PW);
		dbExecuteUpdate(query2);
		Sel.set(main);
	}
	
	private String dbChkID(String query) {
		try {
			result = st.executeQuery(query);
			result.next();
			return result.getString("CHK");
			
		} catch (SQLException e) {
			System.out.println("SQLException: " + e.getMessage());
			System.out.println("SQLState: " + e.getSQLState());
			return "e";
		}
	}
	
	private String dbLogin(String query) {
		try {
			result = st.executeQuery(query);
			if(result.next()) {
				return result.getString("mem_PW");
			}
			else {return "ID_no_match";}
		} catch (SQLException e) {
			System.out.println("SQLException: " + e.getMessage());
			System.out.println("SQLState: " + e.getSQLState());
			return "error";
		}
	}
	
	void B_write() {
		System.out.println("=======================================");
		System.out.print("글 제목: ");
		String title = Board.sc.nextLine();
//		System.out.print("작성자: ");
		String writerID = CurrentID;
		System.out.print("글 내용: ");
		String context = Board.sc.nextLine();
		System.out.println("=======================================");
		
		String input = String.format("INSERT INTO board_basic (b_title,b_writerID,b_datetime,b_cont) VALUES ('%s','%s',now(),'%s');", title, writerID, context);
		dbExecuteUpdate(input);
		total_post++;
		max_page();
		
		Sel.set(LI);
	}
	
	boolean B_readIn(String b_no) { //글 조회 화면 
		String se_query = String.format("SELECT * FROM board_basic WHERE b_no ='%s' AND b_title IS NOT NULL;",b_no);
		if(dbRD(se_query)) {
			System.out.print("----->");
			if(isSigned) {System.out.print("[1.댓글 작성]");}
			if(isSigned && CurrentID.equals(Currentpost_writerID)) {
				System.out.print("[2.글 삭제][3.글 수정]");
			}
			System.out.print("[x.목록으로] | 명령:");
			
//			if(isSigned) {
//			Display.drawB_ReadIN_Signed();		
			String which = Board.sc.nextLine(); 
				if(which.equals("1") && isSigned) {while(B_reply(b_no)); Sel.set(UP);} // 1.댓글 작성 --> 원글 조회
				else if(which.equals("2") && CurrentID.equals(Currentpost_writerID)) {B_remove(b_no);}// 2. 글 삭제
				else if(which.equals("3") && CurrentID.equals(Currentpost_writerID)) {B_update(b_no); Sel.set(UP);}// 3. 글 수정 --> 원글 조회
				else if(which.equals("x")) {Sel.set(LI); }// x. 목록으로
				return true;
//			}
//			else {
//				Display.drawB_ReadIN();		
//				String which = Board.sc.nextLine();
//				if(which.equals("x")) {Sel.set(LI); }// x. 목록으로
//				return true;
//			}
		}
		
		return false;
	}
	
	boolean B_reply(String b_no) { //input b_no = 조회한 원 글 번호
		System.out.print("[1.원글에 작성][2.대댓글 작성]");
		String which = Board.sc.nextLine();
		
		if(which.equals("1")) {
//			System.out.print("작성자 :");
			String writerID = CurrentID;
			System.out.print("내용 :");
			String context = Board.sc.nextLine();
			String query = String.format("INSERT INTO board_basic (b_writerID, b_datetime, b_cont, tag_b_no) VALUES ('%s', now(), '%s', '%s');",
					writerID, context, b_no);
			dbExecuteUpdate(query);
			return false;
		}
		else if(which.equals("2")) {
			System.out.print("태그할 댓글 번호 :");
			String tag_b_no = Board.sc.nextLine();
//			System.out.print("\n작성자 :");
			String writerID = CurrentID;
			System.out.print("내용 :"); 
			String context = Board.sc.nextLine();
			String query = String.format("INSERT INTO board_basic (b_writerID, b_datetime, b_cont, tag_b_no) VALUES ('%s', now(), '%s', '%s');",
					writerID, context, tag_b_no);
			dbExecuteUpdate(query);
			return false;
		}
		
		return true;
	}
	
	void B_list() {//글 리스트
		Display.drawList();
		String query = String.format("SELECT * FROM board_basic WHERE b_title IS NOT NULL LIMIT %s, %s", (current_page - 1) * 5, Integer.toString(postperpage));//
		dbPageList(query, Max_Page);// 리스트 출력
		System.out.println("=======================================================================");
		while(true) {
			if(isSigned)Display.drawListExec_signed();
			else Display.drawListExec();
			String search = Board.sc.nextLine();//조회할 글 번호 입력
			Board.searched_no = search;
			if(search.equals("a")) {if(current_page>1)current_page--; break;} //a. 이전페이지
			else if(search.equals("d")) {current_page++; if(current_page > Max_Page) {current_page=1;} break;} //b. 다음페이지 - 마지막페이지 도달 시 1페이지로
			else if(search.equals("w") && isSigned) {Sel.set(WR);break;} // x:메인으로
			else if(search.equals("x")) {Sel.set(main);break;} // x:메인으로
			
			if(B_readIn(search)) break;
		}
	}
	
	void B_update(String b_no) { // 글 수정
		System.out.print("수정 글 내용: ");
		String toCont = Board.sc.nextLine();
		String query = String.format("UPDATE board_basic SET b_cont = '%s' WHERE b_no = '%s';", toCont, b_no);
		dbExecuteUpdate(query);
	}
	
	void B_remove(String b_no) {// 글 삭제
		String query = String.format("DELETE FROM board_basic WHERE b_no = '%s';", b_no);
		dbRemove(query); 
		if (total_post % postperpage == 1) {current_page--;}//페이지의 유일한 글 삭제 시 현재 페이지 갱신
		total_post--;
		max_page();
	}
	

	private void dbInit() { //db로드
		try {
			// (1/n) 디비 접속 정보 넣어서 접속하기
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/board_pj", "root", "root");
			// (2/n) Statement 객체 얻어오기.
			st = con.createStatement(); // Statement는 정적 SQL문을 실행하고 결과를 반환받기 위한 객체다. Statement하나당 한개의 ResultSet 객체만을 열
										// 수있다.
		} catch (SQLException e) {
			System.out.println("SQLException: " + e.getMessage());
			System.out.println("SQLState: " + e.getSQLState());
		}
	}

	private boolean dbRD(String query) {//글 조회
		int t = 0;
		String b_no = null;
		try {
			result = st.executeQuery(query);
			while (result.next()) { // 결과를 하나씩 빼기. 더 이상 없으면(행 수가 끝나면) false 리턴됨.
				Currentpost_writerID = result.getString("b_writerID");
				b_no = result.getString("b_no");
				System.out.println("*   *   *   *   *   *   *   *   *   *   *   *   *   *   *   *   *");
				System.out.print("제목:"+result.getString("b_title"));
				System.out.print(" | 작성자:"+result.getString("b_writerID"));
				System.out.print(" | 작성시간:"+result.getString("b_datetime")+"\n");
				System.out.println("글 내용:"+result.getString("b_cont"));
				t++;
			}
		} catch (SQLException e) {
			System.out.println("SQLException: " + e.getMessage());
			System.out.println("SQLState: " + e.getSQLState());
		}
		if(t==0) {return false;}//글 번호 validity체크
		
		
		int i = 0; //reply재귀용 인덱스
		if(b_no != null) {dbReply(b_no, i);}
		System.out.println("*   *   *   *   *   *   *   *   *   *   *   *   *   *   *   *   *");
		
		return true;
	}
	
	private int dbMaxPage(String query) {//게시글 수 조회 
		int t = 0;
		try {
			result = st.executeQuery(query);
			result.next(); 
			t = Integer.parseInt(result.getString("COUNT(*)"));
			
		} catch (SQLException e) {
			System.out.println("SQLException: " + e.getMessage());
			System.out.println("SQLState: " + e.getSQLState());
		}
		
		return t;//전체 게시글 수
	}
	
	private void dbRemove(String query) { // 글삭제 db
		try {
			int resultCount = st.executeUpdate(query);
			System.out.println("처리된 행 수:" + resultCount);
		} catch (SQLException e) {
			System.out.println("SQLException: " + e.getMessage());
			System.out.println("SQLState: " + e.getSQLState());
		}
	}
	
	
	private void dbPageList(String query, int Max_Page) {// 글리스트 (페이징)db
		try {
			result = st.executeQuery(query);
			while (result.next()) { // 결과를 하나씩 빼기. 더 이상 없으면(행 수가 끝나면) false 리턴됨.
				System.out.println(String.format("[%s] 제목: %-20s | 작성자: %s | 작성시간: %s", 
						result.getString("b_no"), result.getString("b_title"), result.getString("b_writerID"), result.getString("b_datetime")));
			}
			for(int i = 1; i< Max_Page+1; i++ ) {
				if(i == current_page) {System.out.print(String.format("<%s>", Integer.toString(i)));}
				else {System.out.print(String.format("[%s]", Integer.toString(i)));}
			}
			System.out.println("");
		} catch (SQLException e) {
			System.out.println("SQLException: " + e.getMessage());
			System.out.println("SQLState: " + e.getSQLState());
		}
	}
	
	private void dbExecuteQuery(String query) {
		try {
			result = st.executeQuery(query); // 이거 하는 순간 디비에 sql(쿼리) 날아감. (디비에 반영됨)
		} catch (SQLException e) {
			System.out.println("SQLException: " + e.getMessage());
			System.out.println("SQLState: " + e.getSQLState());
		}
	}
	
	private void dbExecuteUpdate(String query) {// 글 수정db
		try {
			// (3/n) Statement 객체의 executeUpdate함수에 sql문 실어서 디비에서 실행되게 하기
			int resultCount = st.executeUpdate(query); // 이거 하는 순간 디비에 sql(쿼리) 날아감. (디비에 반영됨)
			System.out.println("처리된 행 수:" + resultCount);
		} catch (SQLException e) {
			System.out.println("SQLException: " + e.getMessage());
			System.out.println("SQLState: " + e.getSQLState());
		}
	}
	
	private void dbReply(String b_no, int i) { //댓글 출력
		int temp = i;//현재 원소 인덱스 // 
		try {
			String query = String.format("SELECT * FROM board_basic WHERE b_title IS NULL AND tag_b_no = '%s'", b_no); //tag_b_no = b_no b_no에 태그된 글 긁어오기
			reply_sts.add(con.createStatement()); // statement, resultset생성
			reply_res.add(reply_sts.get(i).executeQuery(query));
			Statement rep_st = reply_sts.get(i);
			ResultSet rep_res = reply_res.get(i);
			i++;
			reply_indent += "  ";//댓글 들여쓰기 처리
					while (rep_res.next()) {
						System.out.println(String.format("%sㄴ[%s] %s | 작성자:%s | 작성시간:%s ",
								reply_indent, rep_res.getString("b_no"), rep_res.getString("b_cont"), rep_res.getString("b_writerID"), rep_res.getString("b_datetime")));
						b_no = rep_res.getString("b_no");
						
						dbReply(b_no, i);
					}
			rep_st.close(); // statement, resultset해제 및 arraylist에서 제거
			rep_res.close();
			reply_sts.remove(temp);
			reply_res.remove(temp);
			reply_indent = reply_indent.substring(0, reply_indent.length()-2); //들여쓰기 단계 별 제거
		} catch (SQLException e) {
			System.out.println("SQLException: " + e.getMessage());
			System.out.println("SQLState: " + e.getSQLState());
		}
	}
	
	
	void B_search() { //제목 검색, 작성자 검색
		Display.drawB_Read();		
		String which = Board.sc.nextLine(); 
		if(which.equals("1")) {
			System.out.print("\n검색어: ");
			String search2 = Board.sc.nextLine();
			int searchpage;
			int temp =  dbMaxPage(String.format("SELECT COUNT(*) FROM board_basic WHERE b_title LIKE '%%%s%%'",search2))/postperpage;
			if(temp%postperpage == 0) searchpage = temp;
			else {searchpage = temp+1;}//검색리스트의 최대페이지 설정
			System.out.println(searchpage);
			outer:
			while(true) {
				Display.drawList();
				String query = String.format("SELECT * FROM board_basic WHERE b_title LIKE '%%%s%%' LIMIT %s, %s;",search2, (current_page - 1)*5, Integer.toString(postperpage));
				dbPageList(query, searchpage);
				
				while(true) {
					System.out.print("----->조회할 글 번호(a:이전페이지 d:다음페이지 x:뒤로) : ");
					String search = Board.sc.nextLine();//조회할 글 번호 입력
					Board.searched_no = search;
					if(search.equals("a")) {if(current_page>1)current_page--; break;} //a. 이전페이지
					else if(search.equals("d")) {current_page++; if(current_page>searchpage) {current_page=1;} break;} //b. 다음페이지 - 마지막페이지 도달 시 1페이지로
					else if(search.equals("x")) {Sel.set(main);break outer;} // x:메인으로
					
					if(B_readIn(search)) break;
				}
			}
		}
		else if(which.equals("x")) {Sel.set(main);}
	}
	
//	void dbIDchk(String query) {
//		String query2 = String.format("SELECT * FROM member WHERE mem_ID ='%s' AND mem_PW = '%s'", input_ID, input_PW);
//		try {
//			result = st.executeQuery(query);
//			
//		} catch (SQLException e) {
//			System.out.println("SQLException: " + e.getMessage());
//			System.out.println("SQLState: " + e.getSQLState());
//		}
//	}
}
