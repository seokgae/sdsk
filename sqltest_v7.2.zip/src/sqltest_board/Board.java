package sqltest_board;

import java.util.Scanner;

public class Board {
	protected static Scanner sc = new Scanner(System.in);
	
	private ProcBoard br;
	static String searched_no = null;
	static String currentID;

	
	Board() {
		br = new ProcBoard();
		br.run();
		
		while(logic() == true) {}
	}
	
	
	private boolean logic() {
		if(Sel.main) {br.B_main();}
		else if(Sel.MS) {br.B_main_signed();}
		else if(Sel.LO) {br.B_login();}
		else if(Sel.WR) {br.B_write();}
		else if(Sel.LI) {br.B_list();}
		else if(Sel.SI) {br.B_signin();}
		else if(Sel.SE) {br.B_search();}
		else if(Sel.UP) {br.B_readIn(searched_no);}
		else if(Sel.exit) {return false;}
		
		return true;
	}
	
	
}
