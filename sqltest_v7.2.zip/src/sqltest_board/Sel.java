package sqltest_board;

import java.util.ArrayList;

public class Sel {
		protected static boolean main = true; //메인화면
		protected static boolean MS = false; //로그인후 메인화면
		protected static boolean WR = false; //글 작성
		protected static boolean SE = false; //글 검색
		protected static boolean LI = false; //게시판
		protected static boolean SI = false; //게시판
		protected static boolean UP = false; //글 조회
		protected static boolean LO = false; //로그인
		protected static boolean exit = false; // 종료 플래그
		
		
		static void set(String to) {
			main = false;
			MS = false;
			WR = false;
			SE = false;
			LI = false;
			SI = false;
			UP = false;
			LO = false;
			exit = false;
			
			if(to.equals("main")) {
				if (ProcBoard.isSigned) {MS = true;} 
				else {main = true;}
			}
			else if(to.equals("WR")) {WR=true;}
			else if(to.equals("SE")) {SE=true;}
			else if(to.equals("LI")) {LI=true;}
			else if(to.equals("SI")) {SI=true;}
			else if(to.equals("UP")) {UP=true;}
			else if(to.equals("LO")) {LO=true;}
			else if(to.equals("exit")) {exit=true;}
		}
		
}
