package sqltest_board;

public class Display {
	static void drawHead() {
		System.out.println("=======================================");
		System.out.println("* * * * * * * * * * * * * * * * * * * *");
		System.out.println("* * * * * * * * * * * * * * * * * * * *");
		System.out.println("* * * * * * *  BoardTest  * * * * * * *");
		System.out.println("* * * * * * * * * * * * * * * * * * * *");
		System.out.println("* * * * * * * * * * * * * * * * * * * *");
	}
	
	static void drawMenu() {
		System.out.println("=======================================");
		System.out.println("  1.로그인 2.게시판 3.회원가입 x.종료  ");
		System.out.println("=======================================");
	}
	
	static void drawMenuSigned() {
		System.out.println("=======================================");
		System.out.println("  1.로그아웃 2.게시판 3.검색 x.종료    ");
		System.out.println("=======================================");
	}
	
	
	static void drawB_Read() {
		System.out.println("=======================================");
		System.out.println("          1.글 제목 검색 x.뒤로        ");
		System.out.println("=======================================");
	}
	
	static void drawList() {
		System.out.println("");
		System.out.println("===============================[글 목록]===============================");

	}
	
	static void drawListExec_signed() {
		System.out.print("----->조회할 글 번호(w:글 작성 a:이전페이지 d:다음페이지 x:뒤로) : ");
	}
	static void drawListExec() {
		System.out.print("----->조회할 글 번호(a:이전페이지 d:다음페이지 x:뒤로) : ");
	}
	
}
